import { supabase } from './supabaseClient';
import { ServiceComment } from '../types';

export const getRequestsByAccessCode = async (code: string) => {
  const { data } = await supabase.from('service_requests').select('*').eq('client_access_code', code);
  return data;
};

export const getRequests = async () => {
  const { data } = await supabase.from('service_requests').select('*').order('created_at', { ascending: false });
  return data || [];
};

export const updateRequestDriveLink = async (id: string, link: string) => {
  await supabase.from('service_requests').update({ drive_link: link }).eq('id', id);
};

export const getComments = async (requestId: string) => {
  const { data } = await supabase
    .from('service_comments')
    .select('*')
    .eq('request_id', requestId)
    .order('created_at', { ascending: true });
  return data || [];
};

export const sendComment = async (comment: Partial<ServiceComment>) => {
  await supabase.from('service_comments').insert(comment);
};

export const getDrivePreviewUrl = (url?: string) => {
  if (!url) return null;
  const match = url.match(/\/d\/(.+?)\/(edit|view|usp=sharing)?/);
  const fileId = match ? match[1] : null;
  return fileId ? `https://drive.google.com/file/d/\${fileId}/preview` : null;
};