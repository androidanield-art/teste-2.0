import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(SUPABASE_URL || '', SUPABASE_KEY || '');

export const logoutAdmin = async () => await supabase.auth.signOut();
export const getActiveSession = async () => {
  const { data } = await supabase.auth.getSession();
  return !!data.session;
};