import React, { useState, useEffect } from 'react';
import { ServiceRequest } from '../types';
import { getRequestsByAccessCode, getDrivePreviewUrl } from '../services/dataService';
import { supabase } from '../services/supabaseClient';
import { Clock, CheckCircle, PlayCircle, LogOut, MessageSquare, ExternalLink } from 'lucide-react';
import { CommentsSection } from './CommentsSection';

export const ClientPortal = ({ onBack }: any) => {
  const [accessCode, setAccessCode] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [activeChat, setActiveChat] = useState<string | null>(null);

  useEffect(() => {
    const code = sessionStorage.getItem('dnldm_client_access');
    if (code) login(code);
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;
    const channel = supabase.channel('portal-realtime')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'service_requests' }, (payload) => {
        setRequests(prev => prev.map(r => r.id === payload.new.id ? { ...r, ...payload.new } : r));
      }).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [isAuthenticated]);

  const login = async (code: string) => {
    const data = await getRequestsByAccessCode(code.toUpperCase());
    if (data?.length) {
      setRequests(data);
      setIsAuthenticated(true);
      setAccessCode(code.toUpperCase());
      sessionStorage.setItem('dnldm_client_access', code.toUpperCase());
    }
  };

  if (!isAuthenticated) return (
    <div className="min-h-screen flex items-center justify-center bg-black p-6 font-sans">
      <div className="w-full max-w-sm space-y-6">
        <h1 className="text-2xl font-bold text-center tracking-tighter text-white">CLIENT PORTAL</h1>
        <input type="text" placeholder="CÓDIGO DE ACESSO" className="w-full bg-zinc-900 border border-white/10 p-4 text-center text-xl font-mono uppercase focus:border-white transition-colors outline-none text-white" onChange={(e) => setAccessCode(e.target.value)} />
        <button onClick={() => login(accessCode)} className="w-full bg-white text-black p-4 font-bold hover:bg-zinc-200 transition-colors">ACESSAR PROJETOS</button>
        <button onClick={onBack} className="w-full text-zinc-500 text-sm hover:text-white transition-colors">Voltar ao início</button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white p-8 pt-24 font-sans">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-4xl font-black italic tracking-tighter">MEUS PROJETOS</h2>
          <button onClick={() => { sessionStorage.clear(); window.location.reload(); }} className="text-zinc-500 hover:text-white flex items-center gap-2 transition-colors"><LogOut size={16}/> SAIR</button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {requests.map(r => (
            <div key={r.id} className="bg-zinc-900 border border-white/5 rounded-2xl overflow-hidden flex flex-col group">
              {r.drive_link && (
                <div className="h-48 bg-black relative">
                  <iframe src={getDrivePreviewUrl(r.drive_link)!} className="w-full h-full pointer-events-none opacity-40 group-hover:opacity-70 transition-opacity" />
                  <a href={r.drive_link} target="_blank" rel="noreferrer" className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <ExternalLink size={24} />
                  </a>
                </div>
              )}
              
              <div className="p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-bold px-2 py-1 bg-white/10 rounded text-zinc-400 uppercase tracking-widest">{r.serviceType}</span>
                  {r.status === 'Finalizado' ? <CheckCircle className="text-green-500" size={18}/> : <Clock className="text-yellow-500 animate-pulse" size={18}/>}
                </div>
                <div>
                  <h3 className="text-xl font-bold uppercase tracking-tight">{r.clientName}</h3>
                  <p className="text-xs text-zinc-500 font-mono mt-1">Status: {r.status}</p>
                </div>
                <button onClick={() => setActiveChat(r.id)} className="w-full py-3 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center gap-2 hover:bg-white hover:text-black transition-all font-bold text-xs uppercase tracking-widest">
                  <MessageSquare size={16}/> Chat e Ajustes
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {activeChat && (
        <CommentsSection 
          requestId={activeChat} 
          authorName={requests.find(r => r.id === activeChat)?.clientName} 
          role="client" 
          onClose={() => setActiveChat(null)} 
        />
      )}
    </div>
  );
};