import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Send, X } from 'lucide-react';
import { supabase } from '../services/supabaseClient';
import { getComments, sendComment } from '../services/dataService';
import { ServiceComment } from '../types';

export const CommentsSection = ({ requestId, authorName, role, onClose }: any) => {
  const [comments, setComments] = useState<ServiceComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    getComments(requestId).then(setComments);

    const channel = supabase
      .channel(`comments-\${requestId}`)
      .on('postgres_changes', { 
        event: 'INSERT', schema: 'public', table: 'service_comments', filter: `request_id=eq.\${requestId}` 
      }, (payload) => {
        setComments(prev => [...prev, payload.new as ServiceComment]);
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [requestId]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [comments]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    await sendComment({ request_id: requestId, author_role: role, author_name: authorName, content: newComment });
    setNewComment('');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm font-sans">
      <div className="bg-zinc-900 border border-white/10 w-full max-w-lg h-[80vh] flex flex-col shadow-2xl rounded-lg overflow-hidden">
        <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5 text-white">
          <div className="flex items-center gap-2">
            <MessageSquare size={18} className="text-blue-400" />
            <span className="font-bold uppercase tracking-widest text-xs">Chat do Projeto</span>
          </div>
          <button onClick={onClose} className="hover:rotate-90 transition-transform"><X size={20}/></button>
        </div>
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {comments.map((c) => (
            <div key={c.id} className={`flex flex-col \${c.author_role === role ? 'items-end' : 'items-start'}`}>
              <div className={`max-w-[85%] p-3 rounded-2xl \${c.author_role === 'admin' ? 'bg-white text-black rounded-tr-none' : 'bg-zinc-800 text-white border border-white/10 rounded-tl-none'}`}>
                <p className="text-[10px] font-black uppercase mb-1 opacity-50">{c.author_name}</p>
                <p className="text-sm leading-relaxed">{c.content}</p>
              </div>
            </div>
          ))}
        </div>
        <form onSubmit={handleSend} className="p-4 bg-black/50 border-t border-white/10 flex gap-2">
          <input value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Mensagem..." className="flex-1 bg-white/5 border border-white/10 p-3 rounded-full text-sm focus:outline-none focus:border-white transition-colors text-white" />
          <button type="submit" className="bg-white text-black p-3 rounded-full hover:scale-110 transition-transform"><Send size={18}/></button>
        </form>
      </div>
    </div>
  );
};