import React, { useState, useEffect } from 'react';
import { getRequests, updateRequestDriveLink } from '../services/dataService';
import { ServiceRequest } from '../types';
import { MessageSquare, Link as LinkIcon } from 'lucide-react';
import { CommentsSection } from './CommentsSection';

export const AdminPanel = ({ onLogout }: any) => {
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [chatId, setChatId] = useState<string | null>(null);

  useEffect(() => {
    getRequests().then(setRequests);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white p-8 pt-20 font-sans">
      <div className="flex justify-between items-center mb-10">
        <h1 className="text-2xl font-bold italic uppercase tracking-tighter">Painel Admin</h1>
        <button onClick={onLogout} className="text-red-500 text-sm font-bold uppercase">Sair</button>
      </div>
      
      <div className="grid gap-4">
        {requests.map(req => (
          <div key={req.id} className="bg-zinc-900 p-6 border border-white/5 flex flex-col md:flex-row justify-between gap-4 rounded-xl">
            <div>
              <h3 className="font-bold text-lg">{req.clientName}</h3>
              <p className="text-sm text-zinc-400 uppercase tracking-widest text-[10px]">{req.serviceType} — {req.status}</p>
            </div>
            <div className="flex flex-col gap-2 w-full md:w-80">
              <div className="flex items-center gap-2 bg-black p-3 border border-white/10 rounded-lg">
                <LinkIcon size={14} className="text-zinc-500"/>
                <input 
                  type="text" 
                  placeholder="Link Google Drive" 
                  defaultValue={req.drive_link}
                  onBlur={(e) => updateRequestDriveLink(req.id, e.target.value)}
                  className="bg-transparent text-[11px] outline-none w-full text-white"
                />
              </div>
              <button onClick={() => setChatId(req.id)} className="flex items-center justify-center gap-2 text-[10px] bg-white text-black p-3 font-bold uppercase tracking-widest hover:bg-zinc-200 transition-colors rounded-lg">
                <MessageSquare size={14}/> Abrir Chat
              </button>
            </div>
          </div>
        ))}
      </div>

      {chatId && (
        <CommentsSection 
          requestId={chatId} 
          authorName="Daniel Damian" 
          role="admin" 
          onClose={() => setChatId(null)} 
        />
      )}
    </div>
  );
};