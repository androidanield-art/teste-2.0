export enum RequestStatus {
  PENDING = 'Pendente',
  IN_PROGRESS = 'Em Produção',
  COMPLETED = 'Finalizado'
}

export enum ServiceCategory {
  CUSTOM_WEAR = 'Custom Wear',
  DESIGN = 'Design',
  BRANDING = 'Branding'
}

export interface ServiceRequest {
  id: string;
  clientName: string;
  serviceType: ServiceCategory;
  status: RequestStatus;
  drive_link?: string;
  client_access_code: string;
  createdAt: string;
}

export interface ServiceComment {
  id: string;
  request_id: string;
  author_role: 'admin' | 'client';
  author_name: string;
  content: string;
  created_at: string;
}