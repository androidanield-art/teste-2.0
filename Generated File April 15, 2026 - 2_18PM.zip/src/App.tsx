import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { About } from './components/About';
import { RequestForm } from './components/RequestForm';
import { AdminLogin } from './components/AdminLogin';
import { AdminPanel } from './components/AdminPanel';
import { ClientPortal } from './components/ClientPortal';
import { ServiceCategory } from './types';
import { getActiveSession, logoutAdmin } from './services/supabaseClient';

type View = 'home' | 'services' | 'about' | 'contact' | 'admin' | 'client-portal';

const App: React.FC = () => {
  const getInitialView = (): View => {
    const hash = window.location.hash.replace('#', '') as View;
    const validViews: View[] = ['home', 'services', 'about', 'contact', 'admin', 'client-portal'];
    return validViews.includes(hash) ? hash : 'home';
  };

  const [view, setView] = useState<View>(getInitialView);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') as View;
      if (hash && hash !== view) setView(hash);
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [view]);

  useEffect(() => {
    getActiveSession().then((active) => {
      setIsAdminAuthenticated(active);
      setAuthChecked(true);
    });
  }, []);

  const handleNavigate = (newView: string) => {
    const targetView = newView as View;
    setView(targetView);
    window.location.hash = targetView;
    window.scrollTo(0, 0);
  };

  if (!authChecked) return <div className="bg-black min-h-screen flex items-center justify-center"><div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" /></div>;

  const isFullScreen = view === 'admin' || view === 'client-portal';

  return (
    <div className="bg-black min-h-screen text-white font-sans selection:bg-white selection:text-black">
      {!isFullScreen && <Navbar onNavigate={handleNavigate} currentView={view} />}
      {view === 'admin' ? (
        isAdminAuthenticated ? <AdminPanel onLogout={async () => { await logoutAdmin(); setIsAdminAuthenticated(false); handleNavigate('home'); }} /> : 
        <div className="min-h-screen flex items-center justify-center relative">
          <button onClick={() => handleNavigate('home')} className="absolute top-8 left-8 text-gray-500 hover:text-white transition-colors">&larr; Voltar ao site</button>
          <AdminLogin onLoginSuccess={() => setIsAdminAuthenticated(true)} />
        </div>
      ) : view === 'client-portal' ? (
        <ClientPortal onBack={() => handleNavigate('home')} />
      ) : (
        <main>
          {view === 'home' && <><Hero onCtaClick={() => handleNavigate('contact')} /><Services onRequestClick={() => handleNavigate('contact')} /><About /></>}
          {view === 'services' && <div className="pt-20"><Services onRequestClick={() => handleNavigate('contact')} /></div>}
          {view === 'about' && <div className="pt-20"><About /></div>}
          {view === 'contact' && <div className="pt-32 pb-20 px-4 min-h-screen bg-black"><RequestForm /></div>}
        </main>
      )}
    </div>
  );
};
export default App;